function do1(a, fn) {
    return fn('00000' + a);
};

module.exports = do1
