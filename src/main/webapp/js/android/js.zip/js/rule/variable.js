var variableInfo() = {
    
    
    
    
    
}



module.exports = variableInfo;