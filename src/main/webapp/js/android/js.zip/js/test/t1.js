
function fna(){
    console.log('fna')
    return console.fn1(a + ' + jsfn1.', jsfn2);
}

exports.fna = fna;
